﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace _03C_AbstractFactory
{
    
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please Enter your choice");
            string description = Console.ReadLine().Trim().ToLowerInvariant();

            IMachineFactory factory = LoadFactory();
            IMachine machine = factory.CreateInstance(description);
            machine.TurnOn();
            machine.TurnOff();
           

            Console.ReadKey();
        }

        private static IMachineFactory LoadFactory()
        {
            string factoryName = _03d_AbstractFactory.Properties.Settings.Default.DefaultMachineFactory;
            return Assembly.GetExecutingAssembly().CreateInstance(factoryName) as IMachineFactory;
        }
    }
}
