﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _16_Interpreter
{
    public class IngredientList : IExpression
    {
        private readonly List<IIngredient> ingredients;

        public IngredientList(List<IIngredient> ingredients)
        {
            this.ingredients = ingredients;
        }

        public void Interpret(Context context)
        {
            foreach (IIngredient ingredient in ingredients)
                ingredient.Interpret(context);
        }
    }

}
