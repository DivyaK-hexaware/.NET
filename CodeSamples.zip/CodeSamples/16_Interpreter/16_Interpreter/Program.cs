﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _16_Interpreter
{
    class Program
    {
        static void Main(string[] args)
        {
            Sandwhich sandwhich = new Sandwhich(
                new WheatBread(),
                new CondimentList(
                    new List<ICondiment> { new MayoCondiment(), new MustardCondiment() }),
                new IngredientList(
                    new List<IIngredient> { new LettuceIngredient(), new ChickenIngredient() }),
                new CondimentList(new List<ICondiment> { new KetchupCondiment() }),
                new WheatBread());

            sandwhich.Interpret(new Context());


            Console.ReadKey();
        }
    }

}
