﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _16_Interpreter
{
    public class CondimentList : IExpression
    {
        private readonly List<ICondiment> condiments;

        public CondimentList(List<ICondiment> condiments)
        {
            this.condiments = condiments;
        }

        public void Interpret(Context context)
        {
            foreach (ICondiment condiment in condiments)
                condiment.Interpret(context);
        }
    }

}
