﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04C_RefactorAgain
{
    public class GraphBuilder
    {
        private ClassyGraph _classyGraph;

        public ClassyGraph GetGraph()
        {
            return _classyGraph;
        }

        public void CreateGraph()
        {
            _classyGraph = new ClassyGraph();
            _classyGraph.PrimarySeries = new List<double>() { 1, 2, 3, 4, 5 };
            _classyGraph.SecondarySeries = new List<double>() { 4, 5, 6, 7, 8 };
            _classyGraph.ColourType = GraphColourPackage.Sad;
            _classyGraph.GraphType = GraphType.Line;
            _classyGraph.LargeGraphSize = false;
            _classyGraph.Offset = 1.2;
            _classyGraph.ShowShadow = true;
        }
    }
}
