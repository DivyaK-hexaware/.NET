﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04C_RefactorAgain
{
    class Program
    {
        static void Main(string[] args)
        {
            GraphBuilder graphBuilder = new GraphBuilder();
            graphBuilder.CreateGraph();
            ClassyGraph cg = graphBuilder.GetGraph();
            Console.WriteLine(cg);
            Console.ReadKey();
        }
    }
}
