﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03a_SansAbstractFactory
{
    public class Robot : IMachine
    {
        public string Name
        {
            get { return "robot"; }
        }

        public void TurnOn()
        {
            Console.WriteLine("Robot is starting.");
        }

        public void TurnOff()
        {
            Console.WriteLine("Robot is stopping.");
        }
    }
}
