﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03a_SansAbstractFactory
{
    
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please Enter your choice");
            string description = Console.ReadLine();
            IMachine machine = GetMachine(description.Trim().ToLowerInvariant());
            machine.TurnOn();
            machine.TurnOff();

            Console.ReadKey();
        }

        private static IMachine GetMachine(string description)
        {
            switch (description)
            {
                case "robot":
                    return new Robot();
                case "car":
                    return new Car();
                case "oven":
                    return new MicrowaveOven();
                default:
                    return new UnknownMachine();
            }
        }
    }
}
