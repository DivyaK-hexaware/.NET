﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08_BridgePattern
{
    public class Apartment : IBuilding
    {
        public string Description { get; set; }
        public Dictionary<string, string> Rooms { get; set; }

        public Apartment()
        {
            Rooms = new Dictionary<string, string>();
        }

        public void Print(IFormatter formatter)
        {
            Console.WriteLine(formatter.Format("Description: ", Description));
            foreach (KeyValuePair<string, string> room in Rooms)
            {
                Console.WriteLine(string.Concat(formatter.Format("Room: ", room.Key), formatter.Format(", room description: ", room.Value)));
            }
        }

    }

}
