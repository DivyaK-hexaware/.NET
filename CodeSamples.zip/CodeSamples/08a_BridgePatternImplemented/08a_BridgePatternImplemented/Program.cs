﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08_BridgePattern
{
    class Program
    {
        static void Main(string[] args)
        {
            IFormatter formatter = new StandardFormatter();
            Apartment apartment = new Apartment();
            apartment.Description = "Nice apartment.";
            apartment.Rooms.Add("1/A", "Cozy little room");
            apartment.Rooms.Add("2/C", "To be renovated");
            apartment.Print(formatter);

            House house = new House();
            house.Address = "New Street";
            house.Description = "Large family home.";
            house.Owner = "Mr. Smith.";
            house.Print(formatter);

            TrainStation trainStation = new TrainStation();
            trainStation.Director = "Mr. Kovacs";
            trainStation.Location = "Budapest";
            trainStation.NumberOfPassangers = 100000;
            trainStation.NumberOfTrains = 100;
            trainStation.Print(formatter);

            Console.ReadKey();
        }

    }
}
