﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08_BridgePattern
{
    public class House : IBuilding
    {
        public string Description { get; set; }
        public string Owner { get; set; }
        public string Address { get; set; }

        public void Print()
        {
            Console.WriteLine("House: ");
            Console.WriteLine(string.Concat("Description: ", Description, " owner:  ", Owner, " address: ", Address));
        }
    }

}
