﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08_BridgePattern
{
    public class Apartment : IBuilding
    {
        public string Description { get; set; }
        public Dictionary<string, string> Rooms { get; set; }

        public Apartment()
        {
            Rooms = new Dictionary<string, string>();
        }

        public void Print()
        {
            Console.WriteLine("Apartment: ");
            Console.WriteLine(Description);
            foreach (KeyValuePair<string, string> room in Rooms)
            {
                Console.WriteLine(string.Concat("Room: ", room.Key, ", room description: ", room.Value));
            }
        }
    }

}
