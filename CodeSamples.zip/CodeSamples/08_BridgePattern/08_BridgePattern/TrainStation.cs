﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08_BridgePattern
{
    public class TrainStation : IBuilding

    {
        public int NumberOfTrains { get; set; }
        public string Location { get; set; }
        public int NumberOfPassangers { get; set; }
        public string Director { get; set; }

        public void Print()
        {
            Console.WriteLine("Train station: ");
            Console.WriteLine(string.Concat("Number of trains: ", NumberOfTrains, ", Location: ", Location, ", number of passangers: ", NumberOfPassangers
                , ", director: ", Director));
        }
    }

}
