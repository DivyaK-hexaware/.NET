﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09a_ImplementCompositePattern
{
    public class Group : IParticipant
    {
        public string Name { get; set; }
        public List<IParticipant> Members { get; set; }

        public Group()
        {
            Members = new List<IParticipant>();
        }

        public int Gold
        {
            get
            {
                int totalGold = 0;
                foreach (IParticipant member in Members)
                {
                    totalGold += member.Gold;
                }

                return totalGold;
            }
            set
            {
                int eachSplit = (int) (value / Members.Count);
                int leftOver = value % Members.Count;
                foreach (IParticipant member in Members)
                {
                    member.Gold += eachSplit + leftOver;
                    leftOver = 0;
                }
            }
        }

        public void Stats()
        {
            foreach (IParticipant member in Members)
            {
                member.Stats();
            }
        }
    }

}
