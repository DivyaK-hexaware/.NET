﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09a_ImplementCompositePattern
{
    public interface IParticipant
    {
        int Gold { get; set; }
        void Stats();

    }
}
