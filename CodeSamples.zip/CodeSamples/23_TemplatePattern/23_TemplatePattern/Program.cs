﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _23_TemplatePattern
{
    class Program
    {
        static void Main(string[] args)
        {
            OrderShipment service = new UpsOrderShipment();
            service.ShippingAddress = "New York";
            service.Ship(Console.Out);

            OrderShipment serviceTwo = new FedExOrderShipment();
            serviceTwo.ShippingAddress = "Los Angeles";
            serviceTwo.Ship(Console.Out);

            Console.ReadKey();

        }
    }
}
