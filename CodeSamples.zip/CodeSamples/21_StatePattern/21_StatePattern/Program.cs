﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21_StatePattern
{
    class Program
    {
        static void Main(string[] args)
        {
            NewState ns = new NewState();
            Order or = new Order(ns);
            or.Id = 123;
            or.OrderDate = DateTime.Today;
            or.Customer = "ABC Ltd";

            Console.WriteLine("Status " + or.Status);

            or.Ship();

            Console.WriteLine("Status " + or.Status);

            Console.ReadKey();

        }
    }
}
