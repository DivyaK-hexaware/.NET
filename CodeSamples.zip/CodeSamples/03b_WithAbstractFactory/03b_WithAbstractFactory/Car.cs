﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03b_WithConcreteFactory
{
    public class Car : IMachine
    {
        public string Name
        {
            get { return "car"; }
        }

        public void TurnOn()
        {
            Console.WriteLine("Car is starting.");
        }

        public void TurnOff()
        {
            Console.WriteLine("Car is stopping.");
        }
    }
}
