﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03b_WithConcreteFactory
{
    
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the machine to create");
            string description = Console.ReadLine().Trim().ToLowerInvariant();
            IMachine machine = new MachineFactory().CreateInstance(description);
            machine.TurnOn();
            machine.TurnOff();

            Console.ReadKey();
        }

    
    }
}
