﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03C_StaticFactory
{
    public interface IMachine
    {
        string Name { get; }
        void TurnOn();
        void TurnOff();
    }
}
