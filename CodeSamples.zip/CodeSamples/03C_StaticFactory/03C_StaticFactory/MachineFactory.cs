﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace _03C_StaticFactory
{
    
    public class MachineFactory
    {
       static Dictionary<string, Type> machines = new Dictionary<string, Type>();

       

        public static IMachine CreateInstance(string description)
        {
            if (machines.Keys.Count <= 0)
            {
                LoadTypesICanReturn();
            }
            Type t = GetTypeToCreate(description);

            if (t == null)
                return new UnknownMachine();

            return Activator.CreateInstance(t) as IMachine;
        }

        private static Type GetTypeToCreate(string machineName)
        {
            
            foreach (var machine in machines)
            {
                if (machine.Key.Contains(machineName))
                {
                    return machines[machine.Key];
                }
            }

            return null;
        }

        private static void LoadTypesICanReturn()
        {
            
            Type[] typesInThisAssembly = Assembly.GetExecutingAssembly().GetTypes();

            foreach (Type type in typesInThisAssembly)
            {
                if (type.GetInterface(typeof(IMachine).ToString()) != null)
                {
                    machines.Add(type.Name.ToLower(), type);
                }
            }
        }
    }
}
