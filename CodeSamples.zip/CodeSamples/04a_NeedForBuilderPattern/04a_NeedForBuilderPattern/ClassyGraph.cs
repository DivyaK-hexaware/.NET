﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04a_NeedForBuilderPattern
{
    public class ClassyGraph
    {
        private List<double> _primarySeries;
        private List<double> _secondarySeries;
        private bool _showShadow;
        private bool _largeGraphSize;
        private double _offset;
        private GraphType _graphType;
        private GraphColourPackage _colourType;

        public ClassyGraph(List<double> primarySeries, List<double> secondarySeries,
            bool showShadow, bool largeGraphSize, double offset,
            GraphType graphType, GraphColourPackage colourType)
        {
            _primarySeries = primarySeries;
            _secondarySeries = secondarySeries;
            _showShadow = showShadow;
            _offset = offset;
            _largeGraphSize = largeGraphSize;
            _graphType = graphType;
            _colourType = colourType;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Graph type: ").Append(_graphType).Append(Environment.NewLine)
                .Append("Colour settings: ").Append(_colourType).Append(Environment.NewLine)
                .Append("Show shadow: ").Append(_showShadow).Append(Environment.NewLine)
                .Append("Is large: ").Append(_largeGraphSize).Append(Environment.NewLine)
                .Append("Offset: ").Append(_offset).Append(Environment.NewLine);
            sb.Append("Primary series: ");
            foreach (double d in _primarySeries)
            {
                sb.Append(d).Append(", ");
            }
            sb.Append(Environment.NewLine).Append("Secondary series: ");
            foreach (double d in _secondarySeries)
            {
                sb.Append(d).Append(", ");
            }
            return sb.ToString();
        }
    }

    public enum GraphType
    {
        Bar
        , Line
        , Stack
        , Pie
    }

    public enum GraphColourPackage
    {
        Sad
        , Beautiful
        , Ugly
    }
}
