﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04a_NeedForBuilderPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            ClassyGraph graph = new ClassyGraph(new List<double>() { 1, 2, 3, 4, 5 },
                                                new List<double>() { 4, 5, 6, 7, 8 }, true, false,
                                                1.2, GraphType.Bar, GraphColourPackage.Sad);
            Console.WriteLine(graph);
            Console.ReadKey();
        }
    }
}
