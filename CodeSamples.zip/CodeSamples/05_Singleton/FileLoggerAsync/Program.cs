﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.Unity;

namespace FileLoggerAsync
{
    class Program
    {
        private static UnityDependencyResolver _dependencyResolver;
        private static INumberWriter _numberWriter;

        private static void RegisterTypes()
        {
            _dependencyResolver = new UnityDependencyResolver();
            _dependencyResolver.EnsureDependenciesRegistered();
            _dependencyResolver.Container.RegisterType<INumberWriter, AsyncNumberWriter>();

        }

        public static void Main(string[] args)
        {
            RegisterTypes();
            _numberWriter = _dependencyResolver.Container.Resolve<INumberWriter>();
            _numberWriter.WriteNumbersToFile(100);
            Console.WriteLine("File write done.");
            Console.ReadLine();
        }
    }
}
