﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileLoggerAsync
{
    public class FileLoggerLazySingleton : IFileLogger
    {
        private readonly TextWriter _logfile;
        private const string filePath = @"e:\logfile.txt";

        private FileLoggerLazySingleton()
        {
            _logfile = GetFileStream();
        }

        public static FileLoggerLazySingleton Instance
        {
            get
            {
                return Nested.instance;
            }
        }
        private class Nested
        {
            static Nested()
            {
            }

            internal static readonly FileLoggerLazySingleton instance = new FileLoggerLazySingleton();
        }

        public void WriteLineToFile(string value)
        {
            _logfile.WriteLine(value);
        }

        public void CloseFile()
        {
            _logfile.Close();
        }

        private TextWriter GetFileStream()
        {
            return TextWriter.Synchronized(File.AppendText(filePath));
        }
    }
}
