﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05_Singleton
{
    public class ThreadSafeSingleton
    {
        private ThreadSafeSingleton()
        {
        }

        public static ThreadSafeSingleton Instance
        {
            get { return Nested.instance; }
        }

        private class Nested
        {
            static Nested()
            {
            }

            internal static readonly ThreadSafeSingleton instance = new ThreadSafeSingleton();
        }
    }
}
