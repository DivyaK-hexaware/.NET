﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _18_MediatorPattern
{
    public class Tower : IAirTrafficControl
    {
        private readonly IList<Aircraft> _aircraftUnderGuidance = new List<Aircraft>();

        public string WarningMessage { get; set; }

        public static StringBuilder Warnings = new StringBuilder(String.Empty);
       

        public void ReceiveAircraftLocation(Aircraft reportingAircraft)
        {
            foreach (Aircraft currentAircraftUnderGuidance in _aircraftUnderGuidance.
                Where(x => x != reportingAircraft))
            {
                if (Math.Abs(currentAircraftUnderGuidance.Altitude - reportingAircraft.Altitude) < 1000)
                {
                    reportingAircraft.Climb(1000);
                    //communicate to the class
                    WarningMessage= currentAircraftUnderGuidance.WarnOfAirspaceIntrusionBy(currentAircraftUnderGuidance);
                    

                    Warnings.Append(WarningMessage);
                    Warnings.Append("\n");
                }
            }
        }

        public void RegisterAircraftUnderGuidance(Aircraft aircraft)
        {
            if (!_aircraftUnderGuidance.Contains(aircraft))
            {
                _aircraftUnderGuidance.Add(aircraft);
            }
        }
    }

}
