﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _18_MediatorPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            IAirTrafficControl tower = new Tower();

            Aircraft flight1 = new Airbus("AC159", tower);
            Aircraft flight2 = new Boeing("WS203", tower);
            Aircraft flight3 = new Fokker("AC602", tower);

            flight1.Altitude += 10000;
            flight2.Altitude += 10500;
            flight3.Altitude += 10700;
            Console.WriteLine(Tower.Warnings);
            Console.ReadKey();

        }
    }
}
