﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_NeedForObserverPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            RunNaiveExample();
            Console.ReadKey();

        }
        private static void RunNaiveExample()
        {
            IEnumerable<Commodity> commodities = new CommodityRepository().GetAllCommodities();
            foreach (Commodity commodity in commodities)
            {
                if (commodity.Name == "cocoa")
                {
                    Console.WriteLine("The current price of cocoa is {0}", commodity.Price);
                }

                if (commodity.Name == "milk" && commodity.Price > 2m)
                {
                    Console.WriteLine("The price of milk has now reached {0}", commodity.Price);
                }
            }
        }

    }
}
