﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05a_ProtoTypePattern
{
    class Program
    {
        static void Main(string[] args)
        {
            DocumentReader reader = new DocumentReader(new Uri("http://bbc.co.uk"));
            reader.PrintPageData();

            //This is where the need for the prototype pattern is felt
            DocumentReader reader1 = new DocumentReader(new Uri("http://bbc.co.uk"));
            reader1.PrintPageData();


            Console.ReadKey();

        }
    }
}
