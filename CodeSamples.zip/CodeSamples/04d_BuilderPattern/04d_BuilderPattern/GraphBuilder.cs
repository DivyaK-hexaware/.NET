﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04d_BuilderPattern
{
    public class GraphBuilder : GraphBuilderBase
    {
        public override void BuildGraphType()
        {
            Graph.GraphType = GraphType.Line;
            Graph.Offset = 1.2;
        }

        public override void ApplyAppearance()
        {
            Graph.ColourType = GraphColourPackage.Sad;
            Graph.LargeGraphSize = false;
            Graph.ShowShadow = true;
        }

        public override void ApplySeries()
        {
            Graph.PrimarySeries = new List<double>() { 1, 2, 3, 4, 5 };
            Graph.SecondarySeries = new List<double>() { 4, 5, 6, 7, 8 };
        }
    }
}
