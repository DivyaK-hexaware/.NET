﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05b_PrototypePattern
{
    class Program
    {
        static void Main(string[] args)
        {
            DocumentReader reader = new DocumentReader(new Uri("http://bbc.co.uk"));
            reader.PrintPageData();

            DocumentReader readerClone = reader.Clone() as DocumentReader;
            readerClone.PrintPageData();

            Console.ReadKey();
        }
    }
}
