﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace _05b_PrototypePattern
{
    public class DocumentReader : ICloneable
    {
        private string _pageTitle;
        private int _headerCount;
        private string _bodyContent;

        public DocumentReader(Uri uri)
        {
            HttpClient httpClient = new HttpClient();
            Task<string> contents = httpClient.GetStringAsync(uri);
            string stringContents = contents.Result;
            Analyse(stringContents);
        }

        private void Analyse(string stringContents)
        {
            _pageTitle = "Homepage";
            _headerCount = 2;
            _bodyContent = "Welcome to my homepage";
        }

        public void PrintPageData()
        {
            Console.WriteLine("Page title: {0}, header count: {1}, body: {2}", _pageTitle, _headerCount, _bodyContent);
        }

        // Please note the that MemberwiseClone is only for shallow copy where there are no complex types involved
        
        public object Clone()
        {
            return MemberwiseClone();
        }

    }

}
