﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20a_ObserverPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            RunEventBasedExample();
            Console.ReadKey();
        }
        private static void RunEventBasedExample()
        {
            CommodityMonitor monitor = new CommodityMonitor();

            CocoaObserver cocoaObserver = new CocoaObserver(monitor);
            MilkObserver milkObserver = new MilkObserver(monitor);

            IEnumerable<Commodity> commodities = new CommodityRepository().GetAllCommodities();
            foreach (Commodity commodity in commodities)
            {
                monitor.Commodity = commodity;
            }
        }

    }
}
