﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;


namespace _12_Flyweight
{
    public interface IWindow
    {
        void Draw(Graphics g, int x, int y, int width, int height);
    }

}
