﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace _12_Flyweight
{
    public class RedWindow : IWindow
    {
        public static int ObjectCounter = 0;
        Brush paintBrush;

        public RedWindow()
        {
            paintBrush = Brushes.Red;
            ObjectCounter++;
        }

        public void Draw(Graphics g, int x, int y, int width, int height)
        {
            g.FillRectangle(paintBrush, x, y, width, height);
        }
    }

}
