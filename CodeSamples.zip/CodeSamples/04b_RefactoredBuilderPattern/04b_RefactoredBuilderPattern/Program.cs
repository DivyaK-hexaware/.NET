﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04b_RefactoredBuilderPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            ClassyGraph cg = new ClassyGraph();
            cg.PrimarySeries = new List<double>() { 1, 2, 3, 4, 5 };
            cg.SecondarySeries = new List<double>() { 4, 5, 6, 7, 8 };
            cg.ColourType = GraphColourPackage.Sad;
            cg.GraphType = GraphType.Line;
            cg.LargeGraphSize = false;
            cg.Offset = 1.2;
            cg.ShowShadow = true;
            Console.WriteLine(cg);
            Console.ReadKey();

        }
    }
}
