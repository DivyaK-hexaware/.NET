﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06_ObjectPooling
{
    class Employee

    {

        public static int Counter = 0;

        public Employee()

        {

            ++Counter;

        }



        private string _Firstname;

        public string Firstname

        {

            get
            {

                return _Firstname;

            }
            set
           {
                _Firstname = value;

            }

        }

    }

}


