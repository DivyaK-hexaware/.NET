﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09_NeedForCompositePattern
{
    public class Group
    {
        public string Name { get; set; }
        public List<Player> Members { get; set; }

        public Group()
        {
            Members = new List<Player>();
        }
    }

}
