﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace _14_ChainOfResponsibility
{
    class Purchase
 {
   private int _number;
   private double _amount;
   private string _purpose;
   // Constructor
   public Purchase(int number, double amount, string purpose)
   {
     this._number = number;
     this._amount = amount;
     this._purpose = purpose;
   }
    // Gets or sets purchase number
    public int Number
    {
      get { return _number; }
      set { _number = value; }
    }
    // Gets or sets purchase amount
    public double Amount
    {
      get { return _amount; }
      set { _amount = value; }
    }
    // Gets or sets purchase purpose
    public string Purpose
    {
      get { return _purpose; }
      set { _purpose = value; }
    }
  }
}
